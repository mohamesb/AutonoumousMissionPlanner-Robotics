#!/usr/bin/env python3

import rospy
import random
import numpy as np
import networkx as nx
from visualization_msgs.msg import Marker, MarkerArray
from geometry_msgs.msg import Point
from ca2_ttk4192.srv import isThroughObstacle, isThroughObstacleRequest, isInObstacle, isInObstacleRequest, positionControl, positionControlRequest

rospy.init_node('RRT')



point_in_obstacle_service = rospy.ServiceProxy('point_in_obstacle', isInObstacle)
path_through_obstacle_service = rospy.ServiceProxy('path_through_obstacle', isThroughObstacle)
position_control_service = rospy.ServiceProxy('/position_control', positionControl)

# Marker publisher
tree_publisher = rospy.Publisher('tree_marker', MarkerArray, queue_size=10)

# RRT Parameters
STEP_SIZE = 0.5
MAX_ITER = 2000
X_LIMITS = (0.0, 5.0)
Y_LIMITS = (0.0, 5.0)




def isInObstacle(vex, radius):
    vex_pos = Point(vex[0], vex[1], 0.0)
    request = isInObstacleRequest(vex_pos, radius)
    response = point_in_obstacle_service(request)

    return response.inObstacle

def isThruObstacle(p0, p1, radius):

    p0_pos = Point(p0[0], p0[1], 0.0)
    p1_pos = Point(p1[0], p1[1], 0.0)

    request = isThroughObstacleRequest(p0_pos, p1_pos, radius)
    response = path_through_obstacle_service(request)

    return response


# Creating marker for RViz
def get_marker(type, pos, size, color, identity):

    marker = Marker()
    marker.header.frame_id = "map"
    marker.type = type
    marker.id = identity
    marker.pose.position.x = pos[0]
    marker.pose.position.y = pos[1]
    marker.pose.position.z = 0.0
    marker.pose.orientation.w = 1.0
    marker.action = Marker.ADD

    marker.scale.x = size
    marker.scale.y = size
    marker.scale.z = 0.001
    marker.color.a = 1.0
    marker.color.r = color[0]
    marker.color.g = color[1]
    marker.color.b = color[2]

    return marker

# Creating edges for RViz
def get_edge_as_marker(first_point, second_point, color, identity, thickness=0.025):

    edge_marker = get_marker(Marker.LINE_STRIP, [0,0], thickness, color, identity)
    
    p0_point = Point(first_point[0], first_point[1], 0.0)
    p1_point = Point(second_point[0], second_point[1], 0.0)
    edge_marker.points.append(p0_point)
    edge_marker.points.append(p1_point)
    
    return edge_marker

# Finds the closes node in the tree to a point
def find_nearest(tree, point):
    nodes = list(tree.nodes)
    distances = [np.linalg.norm(np.array(n) - np.array(point)) for n in nodes]
    return nodes[np.argmin(distances)]

# Attempts to find a new point and add it if not in an obstacle or edge is through obstacle
def extend_tree(tree, nearest, target):
    direction = np.array(target) - np.array(nearest)
    direction = direction / np.linalg.norm(direction) * STEP_SIZE
    new_point = tuple(np.array(nearest) + direction)

    obstacle_check = isInObstacle(new_point, 0.2)

    if obstacle_check:
        return None

    tree.add_edge(nearest, new_point)
    return new_point

# Generates the RRT by random sampling, checks if goal is reached
def build_rrt(start, goal):
    tree = nx.Graph()
    tree.add_node(start)

    for i in range(MAX_ITER):
        rand_point = (random.uniform(*X_LIMITS), random.uniform(*Y_LIMITS))
        nearest = find_nearest(tree, rand_point)
        new_node = extend_tree(tree, nearest, rand_point)

        if new_node and np.linalg.norm(np.array(new_node) - np.array(goal)) < STEP_SIZE:
            tree.add_edge(new_node, goal)
            print("Goal reached! Path found.")
            visualize_tree(tree)  
            return list(nx.shortest_path(tree, start, goal))

        if i % 10 == 0:  # Visualize the tree every 10 iterations
            visualize_tree(tree)
    return None

# Sends path to the position controller
def execute_path(path):
    if not path:
        rospy.logwarn("No valid path found.")
        return
    for waypoint in path:
        request = positionControlRequest(Point(waypoint[0], waypoint[1], 0.0))
        position_control_service(request)

# Publishes to RViz
def visualize_tree(tree):
    """ Publish the RRT tree to RViz using predefined marker functions. """
    tree_marker = MarkerArray()
    marker_identity = 0

    # Mark all nodes (as small cubes)
    node_color = [0.0, 1.0, 0.0]  # Green
    node_size = 0.1

    for node in tree.nodes:
        marker = get_marker(Marker.CUBE, node, node_size, node_color, marker_identity)
        marker_identity += 1
        tree_marker.markers.append(marker)

    # Mark all edges (connections between nodes)
    edge_color = [1.0, 0.0, 0.0]  # Red
    for i, (p1, p2) in enumerate(tree.edges):
        edge_marker = get_edge_as_marker(p1, p2, edge_color, marker_identity)
        marker_identity += 1
        tree_marker.markers.append(edge_marker)

    tree_publisher.publish(tree_marker)



def main():
    start = (0.0, 0.0) # For the short map
    goal = (4.5, 5.0)
    path = build_rrt(start, goal)
    if path:
        execute_path(path)

if __name__ == "__main__":
    main()
